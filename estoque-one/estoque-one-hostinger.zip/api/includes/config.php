<?php
define('DB_FILE', __DIR__ . '/../database.sqlite');
define('JWT_SECRET', 'estoque-one-super-secret-key-123!'); // In production, use env

function getDB() {
    $dsn = "sqlite:" . DB_FILE;
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
}
